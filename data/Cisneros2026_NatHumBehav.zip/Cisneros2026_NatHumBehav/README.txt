OpenMotor dataset Cisneros2026_NatHumBehav

Paper
  Cisneros E, Karny S, Ivry RB, Tsay JS (2026). A systematic investigation reveals dissociable effects of ageing on implicit and explicit components of sensorimotor learning. Nat Hum Behav 10(8):1510-1530.
  https://doi.org/10.1038/s41562-026-02468-7

Lab: Ivry (UC Berkeley) and Tsay (Carnegie Mellon University)

Files
  Cisneros2026_NatHumBehav.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  OpenMotor shares this dataset under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
