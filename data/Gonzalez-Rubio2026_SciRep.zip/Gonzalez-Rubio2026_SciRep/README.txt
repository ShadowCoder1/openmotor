OpenMotor dataset Gonzalez-Rubio2026_SciRep

Paper
  Gonzalez-Rubio M, Iturralde PA, Torres-Oviedo G (2026). Weber's Law in walking: sensory scaling is observed in multi-sensory, dynamic tasks. Sci Rep 16(1):25767.
  https://doi.org/10.1038/s41598-026-54948-5

Lab: Torres-Oviedo (University of Pittsburgh)
Original data deposit: https://osf.io/nfb28/

Files
  Gonzalez-Rubio2026_SciRep.csv     one row per perceptual trial (one judgement of which leg was slower), in the OpenMotor format (37 columns)
  columns.csv   what each column means
  participants.csv   one row per participant (participants_columns.csv says what each column means)

License
  The authors posted these data without a license. This converted version is shared with credit to the
  authors and will be removed on request (open an issue at the OpenMotor GitHub repository).
  Changes made: Kept every row of the authors' trial table and wrote each response with its meaning and correctness, the speed codes as mean belt speeds and the groups by name; added their per-participant JND estimates (mixed-effects and drift-diffusion) as participants.csv; participant numbers are replaced by codes.

How this file was made
  One row is one analysed perceptual trial: after a belt-speed difference was set around a constant mean speed (reference_value, mm/s: 1050 in the reference condition, 700, 1400 or 1750 in the group's testing condition), an audio cue opened a response window (8 strides; 9 s for the fast group) in which the participant pressed the back button of the left or right hand-held controller to say which leg was slower.
  stimulus_value and pert_value are the difference in mm/s, right belt minus left belt (positive: left belt slower; the deposit's data README says m/s, but the values and the authors' code are in mm/s); response is -1 for 'left slower' and 1 for 'right slower'; reaction_time_s runs from the start cue to the press (6 are slightly negative, kept as shared); response_correct is empty on null trials.
  The authors removed the trials without an answer and the first trial after each treadmill start before sharing, so excluded_by_authors is False on every row. For one participant the authors reversed the responses; response follows their left/right choice columns, which their fits use and which are not reversed on that participant's 48 null trials (the deposit's initialResponse column is). block is the authors' block number (blocks alternate the two speeds); which blocks fell on which of the two days is not recorded, so session is empty. Vision of the feet and sound were masked (drape, white noise).
  participants.csv holds, per participant, the group, the testing speed and the authors' JNDs as shared: from their mixed-effects logistic fits (JND_Choices.mat) and from drift-diffusion fits to reaction times (JNDs_RT). The reference-speed trials are the same trials as in the dataset of Gonzalez-Rubio et al. (2025, eNeuro), from the same participants.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 8 numbers reported in the paper, for example:
  - participants: 39 here, 39 in the paper (Methods, Participants)
  - participants in the Comfortable group: 13 here, 13 in the paper (Methods, Participants)
  - participants in the Slow group: 13 here, 13 in the paper (Methods, Participants)
  - participants in the Fast group: 13 here, 13 in the paper (Methods, Participants)
  - mean reference-speed JND as a Weber fraction, % (authors' per-participant estimates): 4.80658 here, 4.807 in the paper (Results, first section (Fig. 2B))
  - paired t-test p, DDM JND, reference vs slow speed (reported p < 0.001): 0.000303174 here, 0 in the paper (Results, DDM section (Fig. 4B))
  - paired t-test p, DDM JND, reference vs fast speed: 0.00197609 here, 0.002 in the paper (Results, DDM section (Fig. 4B))
  - paired t-test p, DDM JND, reference vs comfortable speed: 0.0211249 here, 0.021 in the paper (Results, DDM section (Fig. 4B))

Known differences from the paper
  - The paper's 37 non-response trials cannot be counted: the shared table holds answered trials only (13,059, 8 fewer than the 13,104 planned minus 37), and one participant's block labels give 4 blocks instead of 6, so the paper's 234 blocks are not reproduced by counting labels.
  - The mixed-effects JNDs in JND_Choices.mat give reference 50.469 +- 3.061 mm/s (paper 50.478 +- 3.057) and testing slow 38.149 +- 4.577; comfortable 52.904 +- 4.333; fast 76.903 +- 8.773 mm/s (paper slow 37.941 +- 4.657, comfortable 53.594 +- 4.346, fast 77.588 +- 8.760), and paired t-test p-values slow 0.0109, comfortable 0.9495, fast 0.0001 (paper 0.010, 0.385, < 0.001): close to the paper except the comfortable test, so the deposited estimates seem to come from a slightly different fit than the one reported; the paper's own mixed-model fit is not re-run here.

Please cite the paper above when you use these data.
