OpenMotor dataset Berland2025_JNeurophysiol

Paper
  Berland A, Cherifi YI, Paljic A, Guigon E (2025). Coexistence of two adaptation processes in a visuomotor rotation task. J Neurophysiol 134(5):1531-1539.
  https://doi.org/10.1152/jn.00041.2025

Lab: Guigon (ISIR, Sorbonne) / Paljic (Mines Paris)
Original data deposit: https://zenodo.org/records/15606190

Files
  Berland2025_JNeurophysiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
