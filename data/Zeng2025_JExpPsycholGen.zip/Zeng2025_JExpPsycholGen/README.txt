OpenMotor dataset Zeng2025_JExpPsycholGen

Paper
  Zeng Y, Niziolek CA, Parrell B (2025). Simultaneous acquisition of multiple auditory-motor transformations reveals suprasyllabic motor planning in speech production. Journal of Experimental Psychology: General.
  https://doi.org/10.1037/xge0001744

Lab: Niziolek & Parrell (University of Wisconsin-Madison)
Original data deposit: https://osf.io/ytwqp/

Files
  Zeng2025_JExpPsycholGen.csv     one row per spoken word (utterance) of one participant, in the OpenMotor format (39 columns)
  columns.csv   what each column means

License
  The authors posted these data without a license. This converted version is shared with credit to the
  authors and will be removed on request (open an issue at the OpenMotor GitHub repository).
  Changes made: Merged the authors' per-trial F1, f0 and intensity files into one table, added the feedback shift on each trial from the authors' experiment code, and replaced participant identifiers with codes.

How this file was made
  One row is one word spoken by one participant in Experiment 1, 2 or 3, in the authors' order; trial is the authors' trial number, and its gaps are trials they removed for formant-tracking errors or misproductions.
  f1_mel (F1 in mels), f0_hz, intensity_au (the authors' linear amplitude measure, not dB) and duration_ms are the authors' per-trial values for the first vowel of the word, averaged over the window given in measure_window.
  pert_value and shift_f1 are the F1 shift heard on that trial, in mels, positive when F1 was raised; they were rebuilt from the authors' experiment code: 0 in Baseline and Washout, 30 equal steps from 0 to 125 across the Ramp blocks, 125 in Hold, signed by the word's condition (Upshift +, Downshift -, Unshifted 0).
  subject is one participant's sequence in one experiment and person is the participant, so the two people who took part in both Experiments 1 and 3 have two subject codes and one person code each; rows of the filler word carbonate, which the authors did not analyse, are marked excluded_by_authors.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 22 numbers reported in the paper, for example:
  - Experiment 1: mean % of trials removed per participant: 1.22222 here, 1.22 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Methods, Data processing)
  - Experiment 2: mean % of trials removed per participant: 0.833333 here, 0.83 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Methods, Data processing)
  - Experiment 1: SE of F1 change, Upshift, analysed Hold and Washout blocks (mel): 2.34359 here, 2.34 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Results, Experiment 1)
  - Experiment 1: SE of F1 change, Downshift, analysed Hold and Washout blocks (mel): 2.62852 here, 2.63 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Results, Experiment 1)
  - Experiment 1: SE of F1 change, Unshifted, analysed Hold and Washout blocks (mel): 2.45804 here, 2.45 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Results, Experiment 1)
  - Experiment 2: SE of F1 change, Upshift, analysed Hold and Washout blocks (mel): 2.28917 here, 2.29 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Results, Experiment 2)
  - Experiment 2: SE of F1 change, Downshift, analysed Hold and Washout blocks (mel): 2.33366 here, 2.33 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Results, Experiment 2)
  - Experiment 2: SE of F1 change, Unshifted, analysed Hold and Washout blocks (mel): 2.54733 here, 2.55 in the paper (Zeng, Niziolek & Parrell 2025 (accepted manuscript, PsyArXiv ceqan v2), Results, Experiment 2)
  ... and 14 more.

Known differences from the paper
  - Trials removed per speaker: the shared files give a mean of 0.48% in Experiment 3 (the paper reports 0.44%; the SD and range match) and a maximum of 5.00% in Experiment 1 (the paper reports 3.52%).
  - Share of speakers who adapted: the shared files give 85% in the Experiment 2 Hold phase (paper: 95%) and 75% and 95% in Experiment 3 (paper: 95% and 90%).

Please cite the paper above when you use these data.
