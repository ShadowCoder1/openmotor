OpenMotor dataset Goldschmidt2016_Joystick

Paper
  Goldschmidt D, Dias R (2016). INDP2015 Motor Week joystick visuomotor rotation course project. Unpublished dataset, GitHub degoldschmidt/motor-data.
  https://doi.org/none

Lab: INDP course project (Champalimaud, Lisbon; inferred)
Original data deposit: https://github.com/degoldschmidt/motor-data

Files
  Goldschmidt2016_Joystick.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means
  LICENSE.txt   the license of the original data

License
  The original data are distributed under the GNU General Public License version 3. This converted version is distributed under the same license; the text is in LICENSE.txt.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
