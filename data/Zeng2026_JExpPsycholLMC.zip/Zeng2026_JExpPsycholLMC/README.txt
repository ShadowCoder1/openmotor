OpenMotor dataset Zeng2026_JExpPsycholLMC

Paper
  Zeng Y, Parrell B, Niziolek CA (2026). Transfer of sensorimotor adaptation reveals independent prosodic representation after segment-prosody coordination in speech production. Journal of Experimental Psychology: Learning, Memory, and Cognition 52(9):1638-1654.
  https://doi.org/10.1037/xlm0001551

Lab: Niziolek & Parrell (University of Wisconsin-Madison)
Original data deposit: https://osf.io/d4t6s/

Files
  Zeng2026_JExpPsycholLMC.csv     one row per vowel of one syllable of one spoken word (utterance), or one participant's Transfer1 mean (participant summary), in the OpenMotor format (47 columns)
  columns.csv   what each column means

License
  The authors posted these data without a license. This converted version is shared with credit to the
  authors and will be removed on request (open an issue at the OpenMotor GitHub repository).
  Changes made: Combined the authors' per-trial formant, f0 and intensity tables from their R workspaces into one table, added the formant shift on each trial from the authors' experiment code and shift table, and replaced participant identifiers with codes.

How this file was made
  One row is the vowel /ɛ/ of one syllable of one spoken word (two rows per trial for two-syllable words), in the authors' trial order; trial is the authors' trial number and its gaps are trials they removed for formant-tracking errors or misproductions. f1_mel and f2_mel are F1 and F2 averaged over 25-75% of the vowel (mels); f0_hz (median), intensity_au and intensity_max_au (mean and maximum of the authors' linear intensity track) cover the whole vowel and exist only for the two-syllable words of Experiment 2's Transfer1 and Transfer2 phases (the paper's Pre-training and Post-training).
  The authors shared Transfer1 formants only as each participant's mean per word and syllable, the reference for their transfer measure; these are rows with unit 'participant summary' (F2 only for the 15 participants of their F2 analyses). Transfer1 trial rows hold f0, intensity and duration only.
  pert_value is the size of the shift in the F1-F2 plane in mels (0, a 30-step ramp to 125, 125 in Hold), and shift_f1 and shift_f2 are its F1 and F2 parts, positive when the formant was raised in what the participant heard, from the authors' per-speaker shift table; condition is the syllable's shift (/ɪ/-shift or /æ/-shift) in training phases and the authors' Trained or Novel syllable label in transfer phases; group is the counterbalancing order.
  Masking follows the experiment code: Experiment 2 Baseline and Washout trials played the speech back without masking noise (Audapter feedback mode 1), although the paper describes ~60 dB SPL noise on all trials. The authors' per-sample f0 tracks within each syllable are not included.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 60 numbers reported in the paper, for example:
  - Experiment 1: participants: 20 here, 20 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Participants)
  - Experiment 2: participants: 20 here, 20 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Participants)
  - Experiment 1: % of trials removed per participant, mean: 0.53125 here, 0.53 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Data processing)
  - Experiment 1: % of trials removed per participant, SD: 1.49083 here, 1.49 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Data processing)
  - Experiment 1: % of trials removed per participant, maximum: 6.66667 here, 6.67 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Data processing)
  - Experiment 1: participants whose projected F2 shifts were opposing (/ɪ/-shift up, /æ/-shift down), the F2 analyses' sample: 13 here, 13 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Experiment design)
  - Experiment 2: participants whose projected F2 shifts were opposing (/ɪ/-shift up, /æ/-shift down), the F2 analyses' sample: 15 here, 15 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Experiment design)
  - mean absolute F1 part of the shift, both experiments and directions (mel): 107.619 here, 107.62 in the paper (Zeng, Parrell & Niziolek, manuscript PsyArXiv 63gaj v2 (first revision), Methods, Experiment design)
  ... and 52 more.

Known differences from the paper
  - The paper lists Experiment 2's Baseline as 10 trials and Ramp as 20; the trial numbers in the shared data and the experiment code give 20 Baseline and 30 Ramp trials (with the last 10 Baseline trials as the reference).
  - Trials removed in Experiment 2 (paper: mean 1.53%, SD 1.65%, range 0-4.76%) cannot be recounted, because Transfer1 formants were shared only as means.
  - Numbers that differ from the paper here and equally in the authors' own analysis objects in the shared R workspaces, so most likely typing slips in the paper: Experiment 1 SE of F1 change for the /ɪ/-shift 2.57 (paper 2.56); Experiment 1 Washout, 95% of speakers with a more positive F1 change for the /ɪ/-shift (paper 90%; one speaker's difference is +0.9 mel); Experiment 2 Washout, 14 of the 15 speakers of the F2 analysis with a more negative F2 change for the /ɪ/-shift (paper: all); Table 1 mean F2 perturbation of the F2 adapters 53.90 mel (paper 58.90); SE of F2 transfer for 'head' in bedhead 2.53 (paper 2.46) and for novel syllables 1.45 and 1.20 (the paper prints 1.51 and 1.54, the F1 values).

Please cite the paper above when you use these data.
