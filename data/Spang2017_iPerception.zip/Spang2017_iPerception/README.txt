OpenMotor dataset Spang2017_iPerception

Paper
  Spang K, Wischhusen S, Fahle M (2017). Limited Plasticity of Prismatic Visuomotor Adaptation. i-Perception 8(2):2041669517701458.
  https://doi.org/10.1177/2041669517701458

Lab: Fahle (University of Bremen)
Original data deposit: https://doi.org/10.12751/g-node.hnj28q

Files
  Spang2017_iPerception.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
