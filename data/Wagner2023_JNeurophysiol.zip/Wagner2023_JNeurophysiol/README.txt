OpenMotor dataset Wagner2023_JNeurophysiol

Paper
  Wagner I, Schutz AC (2023). Interaction of dynamic error signals in saccade adaptation. J Neurophysiol 129(3):717-732.
  https://doi.org/10.1152/jn.00419.2022

Lab: Schutz (University of Marburg)
Original data deposit: https://doi.org/10.5281/zenodo.7128739

Files
  Wagner2023_JNeurophysiol.csv     one row per trial (one primary saccade, with the first secondary saccade if any), in the OpenMotor format (55 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/).
  This converted version is shared under the same license.
  Changes made: Converted the trial table (eyeMovementsAndBehavior.csv) to the OpenMotor format with participant codes, left out the empty blocks the authors kept for sessions that were never recorded, and gave target and candidate positions relative to the fixation cross and the target instead of the screen centre; the saccade traces and some per-trial values (raw timestamps, sample numbers, saccade direction angles, a second retinal error) stay only in the original deposit.

How this file was made
  One row is one trial of one participant's session: the upward primary saccade to a target 10 deg above the fixation cross and the first secondary saccade, with the authors' exclusion flags; each of the four conditions was one session of 350 trials on its own day, in an order the deposit does not record, so session is empty and trial counts 1-350 within each condition.
  Eye positions are in deg relative to the fixation cross, y positive upward, and the horizontal axis is the authors' recoded one: positive toward the side where the first candidate appeared for that participant (left for half of the participants, right for the other half).
  pert_value and step_x_deg give the task-relevant candidate's horizontal offset from the target (+2 or -2 deg), shown at online saccade detection in the discriminate-1st conditions (intrasaccadic_step) and 350 ms later in the discriminate-2nd conditions (postsaccadic_step); distractor columns give the other, task-irrelevant candidate, and feedback is none in baseline and retention trials of the small-target experiment, where the target disappeared at saccade detection.
  postsaccadic_error_deg is the authors' retinal error (landing x minus the task-relevant candidate's x), which they also computed in baseline and retention trials where no candidate was shown; the paper's adaptation measure is saccade_amplitude_x_deg minus its mean over the participant's baseline trials.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 24 numbers reported in the paper, for example:
  - small-target, discriminate-1st: mean baseline-corrected horizontal primary saccade amplitude, last adaptation block (deg): 1.07993 here, 1.08 in the paper (Results, 'Obligatory Use of Early Postsaccadic Error Signals in the Small-Target Experiment', Fig. 2E-H)
  - small-target, discriminate-1st: mean baseline-corrected horizontal primary saccade amplitude, first retention block (deg): 0.722936 here, 0.72 in the paper (Results, 'Obligatory Use of Early Postsaccadic Error Signals in the Small-Target Experiment', Fig. 2E-H)
  - small-target, discriminate-1st: mean % of trials excluded per participant: 11.9524 here, 11.95 in the paper (Methods, 'Data exclusion')
  - small-target, discriminate-2nd: mean baseline-corrected horizontal primary saccade amplitude, last adaptation block (deg): 0.505524 here, 0.51 in the paper (Results, 'Obligatory Use of Early Postsaccadic Error Signals in the Small-Target Experiment', Fig. 2E-H)
  - small-target, discriminate-2nd: mean baseline-corrected horizontal primary saccade amplitude, first retention block (deg): 0.574032 here, 0.57 in the paper (Results, 'Obligatory Use of Early Postsaccadic Error Signals in the Small-Target Experiment', Fig. 2E-H)
  - small-target, discriminate-2nd: mean % of trials excluded per participant: 10.7619 here, 10.76 in the paper (Methods, 'Data exclusion')
  - small-target, discriminate-1st-no-2nd: mean baseline-corrected horizontal primary saccade amplitude, last adaptation block (deg): 1.05216 here, 1.05 in the paper (Results, 'Obligatory Use of Early Postsaccadic Error Signals in the Small-Target Experiment', Fig. 2E-H)
  - small-target, discriminate-1st-no-2nd: mean baseline-corrected horizontal primary saccade amplitude, first retention block (deg): 0.783077 here, 0.78 in the paper (Results, 'Obligatory Use of Early Postsaccadic Error Signals in the Small-Target Experiment', Fig. 2E-H)
  ... and 16 more.

Known differences from the paper
  - The large-target experiment has 28 recorded participants here against 29 in the paper: one participant the authors excluded has no data in the deposit. The 24 + 24 analysed participants match.

Please cite the paper above when you use these data.
