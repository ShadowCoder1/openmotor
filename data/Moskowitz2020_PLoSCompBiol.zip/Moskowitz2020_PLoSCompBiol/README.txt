OpenMotor dataset Moskowitz2020_PLoSCompBiol

Paper
  Moskowitz JB, Gale DJ, Gallivan JP, Wolpert DM, Flanagan JR (2020). Human decision making anticipates future performance in motor learning. PLoS Comput Biol 16(2):e1007632.
  https://doi.org/10.1371/journal.pcbi.1007632

Lab: Flanagan (Queen's University) with Wolpert
Original data deposit: https://plos.figshare.com/articles/dataset/Human_decision_making_anticipates_future_performance_in_motor_learning/11915742

Files
  Moskowitz2020_PLoSCompBiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
