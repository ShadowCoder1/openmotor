OpenMotor dataset Stroh2024_JDeafStudDeafEduc

Paper
  Stroh A-L, Overvliet KE, Zierul B, Roesler F, Roeder B (2024). Motor adaptation in deaf and hearing native signers. J Deaf Stud Deaf Educ 29(3):335-349.
  https://doi.org/10.1093/deafed/enae010

Lab: Roeder (University of Hamburg)
Original data deposit: https://www.fdr.uni-hamburg.de/record/12988

Files
  Stroh2024_JDeafStudDeafEduc.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
