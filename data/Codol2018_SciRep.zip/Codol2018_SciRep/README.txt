OpenMotor dataset Codol2018_SciRep

Paper
  Codol O, Holland PJ, Galea JM (2018). The relationship between reinforcement and explicit control during visuomotor adaptation. Sci Rep 8:9121.
  https://doi.org/10.1038/s41598-018-27378-1

Lab: Galea (University of Birmingham)

Files
  Codol2018_SciRep.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  OpenMotor shares this dataset under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
