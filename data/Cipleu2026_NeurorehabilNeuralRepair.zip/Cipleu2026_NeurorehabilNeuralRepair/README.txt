OpenMotor dataset Cipleu2026_NeurorehabilNeuralRepair

Paper
  Cipleu M, Padmanabhan S, Cooper EA, Tsay JS (2026). Minimal impact of low vision on explicit sensorimotor adaptation. Neurorehabil Neural Repair 40(8):643-652.
  https://doi.org/10.1177/15459683261445439

Lab: Tsay (Carnegie Mellon University)

Files
  Cipleu2026_NeurorehabilNeuralRepair.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  OpenMotor shares this dataset under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
