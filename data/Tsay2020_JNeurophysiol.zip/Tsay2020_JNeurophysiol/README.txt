OpenMotor dataset Tsay2020_JNeurophysiol

Paper
  Tsay JS, Parvin DE, Ivry RB (2020). Continuous reports of sensed hand position during sensorimotor adaptation. J Neurophysiol 124(4):1122-1130.
  https://doi.org/10.1152/jn.00242.2020

Lab: Ivry (UC Berkeley)

Files
  Tsay2020_JNeurophysiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  OpenMotor shares this dataset under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
