OpenMotor dataset Matsuda2023_ExpBrainRes

Paper
  Matsuda N, Abe MO (2023). Implicit motor adaptation driven by intermittent and invariant errors. Exp Brain Res 241(8):2125-2132.
  https://doi.org/10.1007/s00221-023-06667-w

Lab: Abe (Hokkaido University)
Original data deposit: https://figshare.com/articles/dataset/Implicit_motor_adaptation_driven_by_intermittent_and_invariant_errors/21212843

Files
  Matsuda2023_ExpBrainRes.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
