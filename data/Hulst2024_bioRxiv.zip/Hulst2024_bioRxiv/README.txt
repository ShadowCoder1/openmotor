OpenMotor dataset Hulst2024_bioRxiv

Paper
  Hulst T, Mamlins A, Frens M, Chang D-I, Goericke SL, Timmann D, Donchin O (2024). Can we improve slow learning in cerebellar patients?. bioRxiv 2020.07.03.185959 (v3, 2024).
  https://doi.org/10.1101/2020.07.03.185959

Lab: Timmann (Essen) / Donchin (Ben-Gurion University)
Original data deposit: https://zenodo.org/records/14541215

Files
  Hulst2024_bioRxiv.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
