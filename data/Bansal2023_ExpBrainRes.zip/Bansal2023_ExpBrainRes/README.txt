OpenMotor dataset Bansal2023_ExpBrainRes

Paper
  Bansal AT, 't Hart BM, Chauhan U, Eggert T, Straube A, Henriques DYP (2023). Motor adaptation does not differ when a perturbation is introduced abruptly or gradually. Exp Brain Res 241:2577-2590.
  https://doi.org/10.1007/s00221-023-06699-2

Lab: Henriques (York University) + Straube/Eggert (LMU Munich)
Original data deposit: https://osf.io/c5ezv/

Files
  Bansal2023_ExpBrainRes.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
