OpenMotor dataset tHart2016_PLoSOne

Paper
  't Hart BM, Henriques DYP (2016). Separating predicted and perceived sensory consequences of motor learning. PLoS ONE 11(9):e0163556 (Table 1 corrected in e0168825).
  https://doi.org/10.1371/journal.pone.0163556

Lab: Henriques ('t Hart; York University)
Original data deposit: https://osf.io/feuby/

Files
  tHart2016_PLoSOne.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data were dedicated to the public domain under CC0 1.0 (https://creativecommons.org/publicdomain/zero/1.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
