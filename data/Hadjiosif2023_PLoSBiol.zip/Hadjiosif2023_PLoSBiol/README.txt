OpenMotor dataset Hadjiosif2023_PLoSBiol

Paper
  Hadjiosif AM, Morehead JR, Smith MA (2023). A double dissociation between savings and long-term memory in motor learning. PLoS Biol 21(4):e3001799.
  https://doi.org/10.1371/journal.pbio.3001799

Lab: Smith (Harvard)
Original data deposit: https://doi.org/10.5281/zenodo.7668262

Files
  Hadjiosif2023_PLoSBiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
