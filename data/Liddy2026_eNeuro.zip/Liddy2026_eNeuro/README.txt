OpenMotor dataset Liddy2026_eNeuro

Paper
  Liddy J, O'Bryan SR, Daskalopoulos A, Song J-H (2026). Automatic, but not autonomous: implicit adaptation is modulated by goal-directed attentional demands. eNeuro 13(3):ENEURO.0243-25.2026.
  https://doi.org/10.1523/ENEURO.0243-25.2026

Lab: Song (Brown University)
Original data deposit: https://github.com/jliddy5/liddy_eneuro_implicit-attention

Files
  Liddy2026_eNeuro.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data were dedicated to the public domain under CC0 1.0 (https://creativecommons.org/publicdomain/zero/1.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
