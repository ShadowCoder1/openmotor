OpenMotor dataset Kim2015_PLoSOne

Paper
  Kim S, Oh Y, Schweighofer N (2015). Between-trial forgetting due to interference and time in motor adaptation. PLoS ONE 10(11):e0142963.
  https://doi.org/10.1371/journal.pone.0142963

Lab: Schweighofer (University of Southern California)
Original data deposit: https://figshare.com/articles/dataset/Kim_et_al_PLoS_One_2015_Between_trial_forgetting_due_to_interference_and_time_in_motor_adaptation/1305124

Files
  Kim2015_PLoSOne.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
