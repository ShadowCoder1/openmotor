OpenMotor dataset Maresch2022_eNeuro

Paper
  Maresch J, Donchin O (2022). Prolonged feedback duration does not affect implicit recalibration in a visuomotor rotation task. eNeuro 9(2):ENEURO.0447-21.2022.
  https://doi.org/10.1523/ENEURO.0447-21.2022

Lab: Donchin (Ben-Gurion University)
Original data deposit: https://osf.io/f6smc/

Files
  Maresch2022_eNeuro.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original deposit lists no license, so the authors keep their rights to these data. OpenMotor shares this converted copy with credit to the authors. Authors who want it changed or removed can open an issue at https://github.com/ShadowCoder1/openmotor/issues.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
