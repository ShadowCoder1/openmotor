OpenMotor dataset Szarka2025_PLoSONE

Paper
  Szarka A, Kim HE, Inglis JT, Chua R (2025). Evidence for an efferent-based prediction contributing to implicit motor adaptation. PLoS ONE 20(4):e0322627.
  https://doi.org/10.1371/journal.pone.0322627

Lab: Chua / H.E. Kim (University of British Columbia)
Original data deposit: https://osf.io/6v3tp/

Files
  Szarka2025_PLoSONE.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data were dedicated to the public domain under CC0 1.0 (https://creativecommons.org/publicdomain/zero/1.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
