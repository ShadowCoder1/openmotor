OpenMotor dataset King2025_bioRxiv

Paper
  King AM, Boulrice JJ, Modchalingam S, Mikula L, 't Hart BM, Henriques DYP (2025). Using tools as cues for motor adaptation in virtual reality. bioRxiv.
  https://doi.org/10.1101/2025.09.02.673800

Lab: Henriques / 't Hart (York University)
Original data deposit: linked from the paper

Files
  King2025_bioRxiv.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original deposit lists no license, so the authors keep their rights to these data. OpenMotor shares this converted copy with credit to the authors. Authors who want it changed or removed can open an issue at https://github.com/ShadowCoder1/openmotor/issues.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
