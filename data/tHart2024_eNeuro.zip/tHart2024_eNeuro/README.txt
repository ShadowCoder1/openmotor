OpenMotor dataset tHart2024_eNeuro

Paper
  't Hart BM, Taqvi U, Gastrock RQ, Ruttle JE, Modchalingam S, Henriques DYP (2024). Measures of implicit and explicit adaptation do not linearly add. eNeuro 11(8):ENEURO.0021-23.2024.
  https://doi.org/10.1523/ENEURO.0021-23.2024

Lab: Henriques ('t Hart; York University)
Original data deposit: https://osf.io/3yhw5/

Files
  tHart2024_eNeuro.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means
  LICENSE.txt   the license of the original data

License
  The original data are distributed under the GNU General Public License version 3. This converted version is distributed under the same license; the text is in LICENSE.txt.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
