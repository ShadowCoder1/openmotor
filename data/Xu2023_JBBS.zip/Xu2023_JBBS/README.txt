OpenMotor dataset Xu2023_JBBS

Paper
  Xu JY, Yang C, Liufu MZ, Chang S, Chen JP, Lu F, Hadjiosif AM, Haith AM, Deng XQ (2023). Effects of Different Feedback Conditions on Sensorimotor Adaptation Revealed in a Mirror Reversal Paradigm. J Behav Brain Sci 13(7):127-141.
  https://doi.org/10.4236/jbbs.2023.137009

Lab: Juan Chen (South China Normal University; data collection), with Haith and Hadjiosif (Johns Hopkins)
Original data deposit: https://github.com/jhanliufu-personal/ImplicitAdaptation2021_Chen

Files
  Xu2023_JBBS.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original deposit lists no license, so the authors keep their rights to these data. OpenMotor shares this converted copy with credit to the authors. Authors who want it changed or removed can open an issue at https://github.com/ShadowCoder1/openmotor/issues.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
