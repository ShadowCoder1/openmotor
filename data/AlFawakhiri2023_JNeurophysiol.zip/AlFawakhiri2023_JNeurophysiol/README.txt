OpenMotor dataset AlFawakhiri2023_JNeurophysiol

Paper
  Al-Fawakhiri N, Ma A, Taylor JA, Kim OA (2023). Exploring the role of task success in implicit motor adaptation. J Neurophysiol 130(2):332-344.
  https://doi.org/10.1152/jn.00061.2023

Lab: Taylor (Princeton)
Original data deposit: https://github.com/kimoli/TaskSuccessImplicitAdapt

Files
  AlFawakhiri2023_JNeurophysiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The authors posted these data without a license. This converted version is shared with credit to the
  authors and will be removed on request (open an issue at the OpenMotor GitHub repository).
  Changes made: converted to the OpenMotor format and participant codes replaced; Experiment 4's target jump sign reversed to match its clamp (see How).

How this file was made
  One row is one reach, all 183,648 the authors shared (204 participants): Experiments 1 and 2 have 880 reaches to 8 targets (5 cycles without a cursor, 10 with, 80 with a 3.5 deg error clamp, 5 without and 10 with a cursor), Experiments 3 and 4 have 100 baseline reaches, 3 tutorial reaches with a 45 deg clamp and 801 or 865 clamp reaches to one target at 90 deg.
  Experiments 3 and 4 are counter-clockwise positive (hand and clamp share the authors' frame; Experiment 4's TargetJump has the opposite sense to its clamp, so target_jump = -TargetJump there). In Experiments 1 and 2 the clamp side was counterbalanced but is not in the files, and the authors stored hand angles with adaptation positive: they are kept as stored, the clamp is written as -3.5 deg in that frame for everyone, and for roughly half of those participants (not identified) the frame is a mirror image of the screen.
  hand_angle is the authors' measure: the angle at peak velocity in Experiments 1-2 (hand_angle_fb is the endpoint angle), at the target distance in Experiments 3-4; excluded_by_authors marks the authors' trial exclusions as their Rmd scripts compute them (3 SD from their running mean, beyond 90 deg, false starts in Experiments 3-4).
  In Experiment 2, reward is the chime (1) or knock (0): on baseline and washout trials the authors' hits flag (the hand within the group's sound zone), on clamp trials the group's sound (Lenient chime, Strict knock). Target sizes in Experiment 4 follow the paper (31 and 4.5 mm; the file codes them 62 and 6); Experiment 3 gives none.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 79 numbers reported in the paper, for example:
  - participants, all four experiments: 204 here, 204 in the paper (Methods, Participants (204 participants))
  - participants, Exp1: 48 here, 48 in the paper (Methods, Participants)
  - participants, Exp2: 96 here, 96 in the paper (Methods, Participants)
  - participants, Exp3: 18 here, 18 in the paper (Methods, Participants)
  - participants, Exp4: 42 here, 42 in the paper (Methods, Participants)
  - Exp4: clamp trials per participant: 865 here, 865 in the paper (Methods, Experiment 4 (865 clamp trials))
  - Exp1 Hit: early learning rate (deg/cycle), mean: 1.39194 here, 1.39194 in the paper (authors' file output_fig1PanelB_earlyLR_meanSEM.csv (the data behind Fig 1B))
  - Exp1 Hit: asymptote, last 10 clamp cycles (deg), mean: 17.2401 here, 17.2401 in the paper (authors' file output_fig1PanelC_asym1_meanSEM.csv (the data behind Fig 1C))
  ... and 71 more.

Known differences from the paper
  - Experiment 1, Miss group: the paper prints an asymptote of 18.88 deg; the rows and the authors' own Fig 1C file give 18.8676 (the SD, 9.33, matches).
  - Experiment 3 has 801 clamp trials per participant in the file; the paper says 800.
  - Experiment 3, No Jump vs Jump-In-Place: t(17) = 1.9651 from the rows (with the authors' exclusions, whose condition means match their Fig 3 files exactly); the paper prints 1.96.
  - Experiments 3 and 4: the authors' 3 SD / 90 deg rule removes 1.2% and 1.3% of clamp trials as their scripts compute it; the paper says under 1% of trials.

Please cite the paper above when you use these data.
