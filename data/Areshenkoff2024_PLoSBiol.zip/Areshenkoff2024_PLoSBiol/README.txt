OpenMotor dataset Areshenkoff2024_PLoSBiol

Paper
  Areshenkoff CN, de Brouwer AJ, Gale DJ, Nashed JY, Smallwood J, Flanagan JR, Gallivan JP (2024). Distinct patterns of connectivity with the motor cortex reflect different components of sensorimotor learning. PLoS Biol 22(12):e3002934.
  https://doi.org/10.1371/journal.pbio.3002934

Lab: Gallivan / Flanagan (Queen's University)
Original data deposit: https://openneuro.org/datasets/ds005598

Files
  Areshenkoff2024_PLoSBiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data were dedicated to the public domain under CC0 1.0 (https://creativecommons.org/publicdomain/zero/1.0/).

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
