OpenMotor dataset Senna2022_eLife

Paper
  Senna I, Piller S, Ben-Zion I, Ernst MO (2022). Recalibrating vision-for-action requires years after sight restoration from congenital cataracts. eLife 11:e78734.
  https://doi.org/10.7554/eLife.78734

Lab: Ernst (Ulm University)
Original data deposit: https://data.mendeley.com/datasets/ksdwxdwtxg

Files
  Senna2022_eLife.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/). This converted version is shared under the same license. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
