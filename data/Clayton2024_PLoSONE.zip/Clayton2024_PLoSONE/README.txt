OpenMotor dataset Clayton2024_PLoSONE

Paper
  Clayton HA, Abbas S, 't Hart BM, Henriques DYP (2024). Visuomotor adaptation across the lifespan. PLoS ONE 19(7):e0306276.
  https://doi.org/10.1371/journal.pone.0306276

Lab: Henriques / 't Hart (York University)
Original data deposit: https://osf.io/kgt2z/

Files
  Clayton2024_PLoSONE.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The authors' processed data are licensed CC BY 4.0 (OSF registration vptqf). The raw files this conversion was made from (OSF project kgt2z) list no license.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
