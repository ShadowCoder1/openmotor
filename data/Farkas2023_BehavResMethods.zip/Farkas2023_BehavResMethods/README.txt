OpenMotor dataset Farkas2023_BehavResMethods

Paper
  Farkas BC, Krajcsi A, Janacsek K, Nemeth D (2023). The complexity of measuring reliability in learning tasks: An illustration using the Alternating Serial Reaction Time Task. Behav Res 56(1):301-317.
  https://doi.org/10.3758/s13428-022-02038-5

Lab: Nemeth (Lyon Neuroscience Research Center / ELTE)
Original data deposit: https://osf.io/9szk7/

Files
  Farkas2023_BehavResMethods.csv     one row per key press (one cued response in the ASRT task), in the OpenMotor format (41 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/).
  This converted version is shared under the same license.
  Changes made: Converted to the OpenMotor format with participant codes replaced; the authors' triplet code column (the last three stimulus positions) and their block-level ACCmean and RTmean columns (the same for every participant, not their own values) were dropped.

How this file was made
  One row is one key press in the learning session of the Alternating Serial Reaction Time task: 45 blocks of 85 trials, each block five random warm-up trials followed by ten repetitions of an 8-element cycle in which random (r) and pattern elements alternate; block is the authors' label, which restarts at 1 every 15 blocks, and block_number counts the 45 blocks.
  Rows keep the authors' file order, which lists blocks 1-15 of every participant, then blocks 16-30, then blocks 31-45, so sort by subject and trial to read each participant's sequence.
  stimulus is the cued position (1-4, left to right; keys Z, C, B, M), correct and rt_ms are the authors' first response (firstACC, firstRT, ms from stimulus onset), rt_correct_ms is their finalRT, the time to the correct key, which the stimulus waited for, and sequence gives each participant's cycle with the pattern positions read from the pattern trials (the same in all 450 cycles).
  excluded_by_authors is true for rows outside the authors' learning scores: warm-up trials, the first two trials of each block, trills, repetitions, first-press RTs of 100 ms or less, and RTs at or above the participant's mean + 3 SD over non-warm-up trials with RT above 100 ms (their trial-wise code takes this cut over high and low triplets only, which moves about 0.07% of rows); RT learning scores used correct first presses only.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 9 numbers reported in the paper, for example:
  - RT learning score split-half r, sequence-wise split, single-stage average: 0.605849 here, 0.606 in the paper (Results, 'Reaction time-based learning scores' and Fig. 2)
  - RT learning score Cronbach alpha, sequence-wise split, single-stage average: 0.753737 here, 0.754 in the paper (Results, 'Reaction time-based learning scores' and Fig. 2)
  - RT learning score split-half r, trial-wise split, two-stage average (0.65449 here, 0.6545 to four decimals; the paper's .655 matches rounding that, so the tolerance is one unit of the third decimal): 0.654487 here, 0.655 in the paper (Results, 'Reaction time-based learning scores' and Fig. 2)
  - RT learning score Cronbach alpha, trial-wise split, two-stage average: 0.791142 here, 0.791 in the paper (Results, 'Reaction time-based learning scores' and Fig. 2)
  - accuracy learning score split-half r, trial-wise split, single-stage average: 0.598337 here, 0.598 in the paper (Results, 'Accuracy-based learning scores' and Fig. 3)
  - accuracy learning score Cronbach alpha, trial-wise split, single-stage average: 0.747244 here, 0.747 in the paper (Results, 'Accuracy-based learning scores' and Fig. 3)
  - accuracy learning score split-half r, sequence-wise split, single-stage average (rows with excluded_by_authors false): 0.531413 here, 0.531 in the paper (Results, 'Accuracy-based learning scores' and Fig. 3)
  - accuracy learning score Cronbach alpha, sequence-wise split, single-stage average (rows with excluded_by_authors false): 0.690226 here, 0.69 in the paper (Results, 'Accuracy-based learning scores' and Fig. 3)
  ... and 1 more.

Please cite the paper above when you use these data.
