OpenMotor dataset Cook2026_InfantChildDev

Paper
  Cook AJ, Giaschi D, Im HY (2026). Speed and accuracy of movement during visuomotor adaptation are still developing in school-age children. Infant Child Dev 35(4):e70121.
  https://doi.org/10.1002/icd.70121

Lab: Im (University of British Columbia)
Original data deposit: https://doi.org/10.5683/SP3/MEH4QW

Files
  Cook2026_InfantChildDev.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY-NC 4.0 by their authors (https://creativecommons.org/licenses/by-nc/4.0/). This converted version is shared under the same license, for non-commercial use only. Changes made: converted to the OpenMotor format and participant codes replaced.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
