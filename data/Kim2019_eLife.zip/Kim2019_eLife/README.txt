OpenMotor dataset Kim2019_eLife

Paper
  Kim HE, Parvin DE, Ivry RB (2019). The influence of task outcome on implicit motor learning. eLife 8:e39882.
  https://doi.org/10.7554/eLife.39882

Lab: Ivry (UC Berkeley)
Original data deposit: https://github.com/hyosubkim/Influence-of-task-outcome-on-implicit-motor-learning

Files
  Kim2019_eLife.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means
  LICENSE.txt   the license of the original data

License
  The original repository is MIT licensed; the license text is in LICENSE.txt.

How this file was made
  The authors' files were converted to the OpenMotor format by a script written for this dataset, and
  the conversion was checked against results reported in the paper. Every trial is kept in order. Angles
  are in degrees, measured from the target, counter-clockwise positive. Participant identifiers were
  replaced by codes that are unique within this dataset: subject is one sequence of trials, person is one
  participant.

Version
  OpenMotor version frozen on 2026-11-04 (content hash 7d24f444841cb106).

Please cite the paper above when you use these data.
