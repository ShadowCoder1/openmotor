OpenMotor dataset Gonzalez-Rubio2019_FrontHumNeurosci

Paper
  Gonzalez-Rubio M, Velasquez NF, Torres-Oviedo G (2019). Explicit Control of Step Timing During Split-Belt Walking Reveals Interdependent Recalibration of Movements in Space and Time. Front Hum Neurosci 13:207.
  https://doi.org/10.3389/fnhum.2019.00207

Lab: Torres-Oviedo (University of Pittsburgh)
Original data deposit: https://doi.org/10.6084/m9.figshare.8145962

Files
  Gonzalez-Rubio2019_FrontHumNeurosci.csv     one row per stride (from a slow-leg heel strike to the next one), in the OpenMotor format (47 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/).
  This converted version is shared under the same license.
  Changes made: Read the deposit's MATLAB (labTools) objects without the lab's code and kept, per stride, the paper's six asymmetry measures, the recording number, the stride start time and the bad-stride flag, with participant codes; participant IDs, dates, the experimenter field, height and weight, and the deposit's empty parameters are left out.

How this file was made
  One row is one stride (slow-leg heel strike to the next) of one participant, in the deposit's order; the deposit keeps per stride only the paper's six asymmetry measures (Sout, Tout, SA, TA, SnA and TnA, in the asymmetry columns) and a bad-stride flag, so the per-leg times and lengths and step_length_asymmetry are empty.
  Fast and slow are the legs on the 1.0 and 0.5 m/s belts during adaptation (the self-reported dominant leg was on the fast belt); both belts ran at 0.75 m/s in the other blocks, and each block was its own recording (planned 150, 150, 600 and 450 strides).
  Values and signs are the deposit's: step_time_asymmetry (Tout) is positive when the fast leg's step lasts longer, as the deposit's own parameter description says and as stance_time_asymmetry minus double_support_asymmetry_s over stride time confirms stride by stride (median difference 0.0002), which is the opposite of how the paper's equation 2 reads; range_of_motion_asymmetry is defined by the paper's equation 5, while the deposit's description gives an angle-based formula that the shared values cannot test.
  excluded_by_authors marks the strides the deposit flags as bad (missing or out-of-order gait events, or a stride time out of range), which the authors' analysis code drops before every result; feedback is normal on every row, and condition is 'feedback on' for the familiarization and adaptation strides of the two feedback groups, who watched their own step position or step time on a screen (one control participant's condition notes also mention feedback in those blocks, but the paper lists every control as walking without it).
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 19 numbers reported in the paper, for example:
  - number of women (13 women, 8 men): 13 here, 13 in the paper (Methods, para 1)
  - mean age, years (24.69 +- 4): 24.6865 here, 24.69 in the paper (Methods, para 1)
  - p-value, Sout steady state vs 0, control: 0.000412576 here, 0.0004 in the paper (Results 3.1, para 1 (Figure 2A))
  - p-value, Tout steady state vs 0, spatial feedback: 0.000375329 here, 0.0004 in the paper (Results 3.1, para 1 (Figure 2A))
  - p-value, Sout after-effect vs 0, control: 0.000326246 here, 0.0003 in the paper (Results 3.1, para 1 (Figure 2B))
  - p-value, Sout after-effect vs 0, spatial feedback: 0.0163823 here, 0.0164 in the paper (Results 3.1, para 1 (Figure 2B))
  - p-value, Tout after-effect vs 0, spatial feedback: 0.102275 here, 0.1023 in the paper (Results 3.1, para 1 (Figure 2B))
  - p-value, SA after-effect vs 0, control: 0.000904399 here, 0.0009 in the paper (Results 3.1, para 2 (Figure 3B))
  ... and 11 more.

Known differences from the paper
  - Three p-values in the Results come out close but not equal from the shared strides: 0.0499 (paper 0.0481), 0.4322 (paper 0.4235) and 0.0101 (paper 0.0092); the other 17 match to 4 decimals.

Please cite the paper above when you use these data.
