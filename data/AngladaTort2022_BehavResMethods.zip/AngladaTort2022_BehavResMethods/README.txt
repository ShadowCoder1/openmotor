OpenMotor dataset AngladaTort2022_BehavResMethods

Paper
  Anglada-Tort M, Harrison PMC, Jacoby N (2022). REPP: A robust cross-platform solution for online sensorimotor synchronization experiments. Behav Res 54(5):2271-2285.
  https://doi.org/10.3758/s13428-021-01722-2

Lab: Jacoby (Max Planck Institute for Empirical Aesthetics)
Original data deposit: https://osf.io/r2pxd/

Files
  AngladaTort2022_BehavResMethods.csv     one row per tap, or stimulus onset that received no tap, in a 30-s tapping trial, in the OpenMotor format (35 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY 4.0 by their authors (https://creativecommons.org/licenses/by/4.0/).
  This converted version is shared under the same license.
  Changes made: Converted to the OpenMotor format with participant codes replaced: each trial's arrays of tap and stimulus onsets were unpacked into one row per tap (or per stimulus onset without a tap); the authors' per-trial summaries (mean and SD of asynchrony, vector length, model fits), the self-reported laptop model and the per-participant musical training score were dropped, and Experiment 1 (a hardware timing calibration) and the figure files were not converted.

How this file was made
  One row is one tap, or one stimulus onset that received no tap, in the 30-s tapping trials of Experiment 2 (lab, 20 participants, each tested twice with REPP on a laptop, condition psynet, and twice with the authors' in-lab loop-back method, condition matlab) and Experiment 3 (online, 226 participants, REPP; block pre and post are test and retest); a trial is isochronous tapping to a metronome (iso_600ms, iso_800ms) or tapping to the beat of a music excerpt (train1, train7).
  tap_time_ms and stimulus_time_ms are the authors' onsets in ms from the start of the trial's recording, aligned on the first marker sound, and asynchrony_ms is their tap minus stimulus (negative when the tap came first); a row without a stimulus is a tap their alignment paired with no stimulus, a row without a tap is a stimulus that got none, iti_ms is given only between taps paired with consecutive stimuli, and all values are whole ms as in the deposit.
  In the music trials a metronome click marked the opening and closing beats (stimulus_played true) and the authors analysed only the beats without it, so those rows are excluded_by_authors; the deposit holds only trials that passed their quality criteria (all six marker sounds found, marker error within 5 ms, 50-200% as many taps as stimuli), so no other rows are excluded.
  Rows keep the authors' file order, which is sorted by stimulus rather than by time, so tapping_trial is not the order in which trials were run (the deposit does not record it); in Experiment 3 group is the recruitment batch and device names the laptop's operating system, where the deposit's codes 1 and 2 are Windows and macOS (their marker errors reproduce the paper's), code 0 is Chrome OS (every laptop reported is a Chromebook) and code 3 is shown as other OS.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 14 numbers reported in the paper, for example:
  - Experiment 3 participants with valid tapping data: 226 here, 226 in the paper (Results, Experiment 3 (and Supplementary, Participants))
  - Experiment 3 tapping trials recorded on Windows or macOS laptops: 2814 here, 2814 in the paper (Fig. 4 legend (2814 trials in total) and Results, Experiment 3 (t(2812)))
  - Experiment 3 participants in the test-retest analysis (a valid trial for each stimulus in each task and test): 166 here, 166 in the paper (Results, Experiment 3)
  - Experiment 3 test-retest Spearman rho of SD of asynchrony: 0.809574 here, 0.81 in the paper (Results, Experiment 3; Fig. 4a)
  - Experiment 3 isochronous task: mean SD of asynchrony (ms): 40.6843 here, 40.68 in the paper (Discussion, third paragraph (N = 166; labelled Experiment 2 there, the online sample is Experiment 3))
  - Experiment 3 isochronous task: SD across participants (ms): 11.9846 here, 11.98 in the paper (Discussion, third paragraph (N = 166; labelled Experiment 2 there, the online sample is Experiment 3))
  - Experiment 3 music task: mean SD of asynchrony (ms): 42.6845 here, 42.68 in the paper (Discussion, third paragraph (N = 166; labelled Experiment 2 there, the online sample is Experiment 3))
  - Experiment 3 music task: SD across participants (ms): 15.8212 here, 15.82 in the paper (Discussion, third paragraph (N = 166; labelled Experiment 2 there, the online sample is Experiment 3))
  ... and 6 more.

Known differences from the paper
  - Experiment 3 test-retest r: the rows and the authors' own Figure 4A data file both give 0.82; the paper prints .80.
  - Experiment 2 REPP test-retest rho: 0.800 from the rows against .81 in the paper, because the deposit rounds asynchronies to 1 ms (the authors' unrounded values give .812).

Please cite the paper above when you use these data.
