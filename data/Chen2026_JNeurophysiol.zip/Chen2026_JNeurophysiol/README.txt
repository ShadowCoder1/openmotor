OpenMotor dataset Chen2026_JNeurophysiol

Paper
  Chen Y, Taylor JA (2026). Revisiting the explicit-implicit additivity assumption in visuomotor adaptation. J Neurophysiol 135(5):1298-1314.
  https://doi.org/10.1152/jn.00525.2025

Lab: Taylor (Princeton)
Original data deposit: https://osf.io/zt8pd/

Files
  Chen2026_JNeurophysiol.csv     one row per trial of one participant sequence, in the OpenMotor format (90 columns)
  columns.csv   what each column means

License
  The original data are licensed CC BY-NC 4.0 by their authors (https://creativecommons.org/licenses/by-nc/4.0/).
  This converted version is shared under the same license.
  Changes made: converted to the OpenMotor format, participant codes replaced, and hand and aim angles flipped back from the authors' compensation-positive sign to counter-clockwise positive.

How this file was made
  One row is one reach: 400 per participant (40 baseline, 200 with a 45 deg rotation, four 30-trial process dissociation blocks of Exclusion, Top-up and Inclusion trials, 40 no-cursor washout trials); all 60 recruited participants are kept and the 2 the authors excluded are flagged.
  The authors stored hand angles and aim reports flipped so that compensation is positive; they were flipped back with the authors' own rule, so hand_angle and aim_report are counter-clockwise positive like target_angle and rotation (rotation -45 is clockwise).
  This sign was checked three ways: hand angles recomputed from the authors' hand x, y and target angle match on every row, participants with the -45 rotation reach about +43 deg late in training, and their aim taps lie left of the start position on the screen.
  hand_angle is the hand direction where the hand passed the 7 cm target distance (the paper's endpoint); block names the process dissociation condition (target at the training or the aiming location, no delay or a 1 min delay); the deposit's pilot data (a separate study) and hand trajectories are not included.
  Participant codes were assigned in order of first appearance: subject is one sequence of rows, person
  is one participant.

Checks against the paper
  The converted rows reproduce 39 numbers reported in the paper, for example:
  - participants recruited: 60 here, 60 in the paper (Methods, Participants ('Sixty participants were recruited'))
  - participants analysed, aiming group: 29 here, 29 in the paper (Methods, Participants (n = 29 per group))
  - participants analysed, control group: 29 here, 29 in the paper (Methods, Participants (n = 29 per group))
  - Aiming: mean hand angle, last 10 training trials: 43.7479 here, 43.75 in the paper (Results, 'Participants successfully adapted')
  - Aiming: SEM of that mean: 0.362942 here, 0.36 in the paper (Results, 'Participants successfully adapted')
  - Aiming: Top-up, target at training location, no delay (mean): 43.8927 here, 43.89 in the paper (Results, 'Participants successfully adapted')
  - Aiming: Top-up, training location, no delay (SEM): 0.492643 here, 0.49 in the paper (Results, 'Participants successfully adapted')
  - Aiming: Inclusion, training location, no delay (mean): 44.0118 here, 44.01 in the paper (Results, 'Participants successfully adapted')
  ... and 31 more.

Please cite the paper above when you use these data.
